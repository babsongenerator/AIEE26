// Small helpers shared by the play, display, and admin pages.

const VW = (() => {
  function deviceId() {
    try {
      let d = localStorage.getItem('vw-device');
      if (!d) {
        d = Math.random().toString(36).slice(2) + Date.now().toString(36);
        localStorage.setItem('vw-device', d);
      }
      return d;
    } catch {
      return 'no-storage';
    }
  }

  const DEVICE = deviceId();

  async function api(path, { method = 'GET', body, pin } = {}) {
    const headers = { 'x-vw-device': DEVICE };
    if (body) headers['content-type'] = 'application/json';
    if (pin) headers['x-admin-pin'] = pin;
    const res = await fetch(path, { method, headers, body: body ? JSON.stringify(body) : undefined, cache: 'no-store' });
    let data = null;
    try {
      data = await res.json();
    } catch {
      data = null;
    }
    if (!res.ok) {
      const err = new Error((data && data.error) || `The server answered with an error (${res.status}).`);
      err.status = res.status;
      throw err;
    }
    return data;
  }

  // Poll on a steady beat. Back off a little while the server is unreachable.
  function poll(fn, ms) {
    let stopped = false;
    let delay = ms;
    async function tick() {
      if (stopped) return;
      try {
        await fn();
        delay = ms;
      } catch (e) {
        delay = Math.min(delay * 1.5, 8000);
      }
      setTimeout(tick, delay + Math.random() * 200);
    }
    tick();
    return () => (stopped = true);
  }

  const money = (n) => {
    const v = Math.round(Number(n) || 0);
    const sign = v < 0 ? '-' : '';
    const a = Math.abs(v);
    if (a >= 1e6) return `${sign}$${(a / 1e6).toFixed(a >= 1e7 ? 0 : 1)}M`;
    if (a >= 1e4) return `${sign}$${Math.round(a / 1000)}k`;
    if (a >= 1000) return `${sign}$${Number((a / 1000).toFixed(1))}k`;
    return `${sign}$${a.toLocaleString('en-US')}`;
  };
  const moneyFull = (n) => {
    const v = Number(n) || 0;
    const cents = Math.round(v * 100) % 100 !== 0;
    return `${v < 0 ? '-' : ''}$${Math.abs(v).toLocaleString('en-US', { minimumFractionDigits: cents ? 2 : 0, maximumFractionDigits: 2 })}`;
  };
  const num = (n) => Math.round(Number(n) || 0).toLocaleString('en-US');
  const pct = (x) => `${x > 0 ? '+' : ''}${Math.round((Number(x) || 0) * 100)}%`;

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  }

  // Server clock offset, so countdowns agree across phones and the projector.
  let offset = 0;
  function syncClock(serverNow) {
    if (serverNow) offset = serverNow - Date.now();
  }
  const now = () => Date.now() + offset;
  const secondsLeft = (deadline) => (deadline ? Math.max(0, Math.ceil((deadline - now()) / 1000)) : 0);

  function shockEffects(shock, scenario, t) {
    if (!shock) return [];
    const all = ['low', 'mid', 'premium'];
    const tiers = shock.tiers && shock.tiers.length ? shock.tiers : all;
    const names = tiers.map((x) => scenario.tiers[x].label.toLowerCase());
    const list = names.length > 1 ? `${names.slice(0, -1).join(', ')} ${t('and')} ${names[names.length - 1]}` : names[0];
    const who = tiers.length === 3 ? t('everyPrice') : t('somePrices', { tiers: list });
    const out = [];
    if (Math.abs(shock.demand - 1) >= 0.005) out.push(t('fxCustomers', { p: pct(shock.demand - 1), who }));
    if (Math.abs(shock.cost - 1) >= 0.005) out.push(t('fxCost', { p: pct(shock.cost - 1), who, unit: scenario.unit }));
    if (!out.length) out.push(t('fxNone'));
    return out;
  }

  // Count a number up to its new value, for the projector.
  function countTo(el, target, fmt, ms = 900) {
    const from = Number(el.dataset.v || 0);
    el.dataset.v = target;
    if (from === target) {
      el.textContent = fmt(target);
      return;
    }
    const t0 = performance.now();
    function step(t) {
      const k = Math.min(1, (t - t0) / ms);
      const e = 1 - Math.pow(1 - k, 3);
      el.textContent = fmt(from + (target - from) * e);
      if (k < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  return { api, poll, money, moneyFull, num, pct, esc, syncClock, now, secondsLeft, shockEffects, countTo, DEVICE };
})();
