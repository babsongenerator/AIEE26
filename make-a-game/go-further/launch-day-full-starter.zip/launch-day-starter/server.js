// Launch Day: a live multiplayer startup game.
// One Express server, static pages in public/, game state in memory with a
// copy written to data/state.json after every change.
//
//   /play     phones (one per team, or several phones on one team)
//   /display  the projector
//   /admin    the host's controls (PIN in the x-admin-pin header)

const express = require('express');
const path = require('node:path');
const fs = require('node:fs');
const crypto = require('node:crypto');
const os = require('node:os');
const QRCode = require('qrcode');
const { resolveMarket, scoreTeams, TIERS, clamp } = require('./lib/model');
const ai = require('./lib/ai');
const { text } = require('./lib/text');

const PORT = Number(process.env.PORT) || 3041;
const HOST = process.env.HOST || '0.0.0.0';
// The address players type or scan. "npm run local" (node server.js --local)
// uses this computer's address on the local network, for a class on one wifi.
function lanAddress() {
  for (const list of Object.values(os.networkInterfaces())) {
    for (const a of list || []) if (a.family === 'IPv4' && !a.internal) return a.address;
  }
  return 'localhost';
}
const LOCAL = process.argv.includes('--local');
const BASE_URL = (process.env.BASE_URL || (LOCAL ? `http://${lanAddress()}:${PORT}` : 'http://jonathans-mac-mini:3041')).replace(/\/+$/, '');
const ADMIN_PIN = process.env.VW_ADMIN_PIN || 'launch';
const DATA_DIR = process.env.VW_DATA_DIR || path.join(__dirname, 'data');
const STATE_FILE = path.join(DATA_DIR, 'state.json');
const SCENARIO_DIR = path.join(__dirname, 'scenarios');
// "npm run local -- --scenario=my-case" picks the market at start, like VW_SCENARIO.
const ARG_SCENARIO = (process.argv.find((x) => x.startsWith('--scenario=')) || '').split('=')[1];
const DEFAULT_SCENARIO = ARG_SCENARIO || process.env.VW_SCENARIO || 'campus-food';
const MAX_TEAMS = 60;
const NAME_MAX = 28;
const MOVE_MAX = 120;

// ---------- Scenarios ----------
// Scenario files are re-read whenever they change on disk, so an edit made
// live by Claude Code applies from the next round without a restart.

const scenarioCache = {};

function listScenarios() {
  return fs
    .readdirSync(SCENARIO_DIR)
    .filter((f) => f.endsWith('.json'))
    .map((f) => {
      const id = f.replace(/\.json$/, '');
      try {
        const s = loadScenario(id);
        return { id, name: s.name, tagline: s.tagline };
      } catch (e) {
        return { id, name: `${id} (this file has an error)`, tagline: e.message, broken: true };
      }
    });
}

function loadScenario(id) {
  const file = path.join(SCENARIO_DIR, `${path.basename(id)}.json`);
  const mtime = fs.statSync(file).mtimeMs;
  const hit = scenarioCache[id];
  if (hit && hit.mtime === mtime) return hit.scenario;
  const scenario = validateScenario(JSON.parse(fs.readFileSync(file, 'utf8')), id);
  scenarioCache[id] = { mtime, scenario };
  return scenario;
}

function validateScenario(s, id) {
  const need = ['name', 'market', 'startingCash', 'roundBudget', 'fixedCostPerRound', 'tiers', 'segments', 'model', 'score'];
  for (const k of need) if (s[k] === undefined) throw new Error(`The scenario "${id}" is missing "${k}".`);
  for (const t of TIERS) if (!s.tiers[t]) throw new Error(`The scenario "${id}" is missing the "${t}" price tier.`);
  s.id = id;
  s.language = ['en', 'es'].includes(s.language) ? s.language : 'en';
  s.unit = s.unit || 'customer';
  s.units = s.units || `${s.unit}s`;
  s.rounds = Number(s.rounds) || 3;
  s.roundSeconds = Number(s.roundSeconds) || 60;
  s.budgetStep = Number(s.budgetStep) || 5000;
  s.shocks = s.shocks || [];
  s.stockQuotes = s.stockQuotes || {};
  s.botNames = s.botNames || [];
  s.botMoves = s.botMoves || [];
  return s;
}

// The scenario in play. If someone saves a broken file mid-game, keep using
// the last good copy and say so on the admin page.
let lastGoodScenario = null;
let scenarioError = null;
function scenario() {
  try {
    lastGoodScenario = loadScenario(state.scenarioId);
    scenarioError = null;
  } catch (e) {
    scenarioError = e.message;
    if (!lastGoodScenario) lastGoodScenario = loadScenario('campus-food');
  }
  return lastGoodScenario;
}

// ---------- State ----------

function freshState(scenarioId) {
  return {
    scenarioId: scenarioId || DEFAULT_SCENARIO,
    phase: 'lobby', // lobby | joining | round | closed | resolving | results | final
    round: 0,
    roundSeconds: null, // null means use the scenario's value
    deadline: null,
    teams: {},
    order: [], // team ids in join order
    rounds: [], // one entry per resolved round
    debrief: null,
    debriefStatus: 'idle', // idle | working | ready
    showRules: false, // the projector shows the rules panel
    aiUsage: { calls: 0, inputTokens: 0, outputTokens: 0, costUsd: 0, estimated: false },
    version: 1,
  };
}

let state = freshState();

function restore() {
  try {
    if (!fs.existsSync(STATE_FILE)) return;
    const saved = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    if (saved && saved.teams && saved.phase) {
      state = { ...freshState(), ...saved };
      // A crash mid-resolve should not leave the game stuck.
      if (state.phase === 'resolving') state.phase = 'closed';
      if (state.debriefStatus === 'working') state.debriefStatus = 'idle';
      console.log(`[state] restored ${state.order.length} teams, round ${state.round}, phase ${state.phase}`);
    }
  } catch (e) {
    console.error('[state] restore failed:', e.message);
  }
}

let persistTimer = null;
function changed() {
  state.version++;
  publicCache = null;
  if (persistTimer) return;
  persistTimer = setTimeout(() => {
    persistTimer = null;
    try {
      fs.mkdirSync(DATA_DIR, { recursive: true });
      fs.writeFileSync(STATE_FILE + '.tmp', JSON.stringify(state));
      fs.renameSync(STATE_FILE + '.tmp', STATE_FILE);
    } catch (e) {
      console.error('[state] write failed:', e.message);
    }
  }, 300);
}

const id = () => crypto.randomBytes(5).toString('hex');

function cleanText(s, max) {
  return String(s || '')
    .replace(/[\u0000-\u001f<>]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, max);
}

function newTeam(name, bot = false) {
  const s = scenario();
  const t = {
    id: id(),
    name,
    bot,
    members: bot ? 0 : 1,
    joinedRound: state.round,
    cash: s.startingCash,
    cumProduct: 0,
    brand: 0,
    totalCustomers: 0,
    totalRevenue: 0,
    score: 0,
    rank: null,
    prevRank: null,
    out: false,
    submission: null,
    history: [],
  };
  state.teams[t.id] = t;
  state.order.push(t.id);
  return t;
}

function activeTeams() {
  return state.order.map((i) => state.teams[i]).filter((t) => t && !t.out);
}

function roundSeconds() {
  return state.roundSeconds || scenario().roundSeconds;
}

function snapToStep(x, s) {
  const step = s.budgetStep;
  return clamp(Math.round((Number(x) || 0) / step) * step, 0, s.roundBudget);
}

function validChoice(body) {
  const s = scenario();
  const tier = TIERS.includes(body.tier) ? body.tier : null;
  if (!tier) return { error: text(s).errPrice };
  let product = snapToStep(body.product, s);
  let marketing = snapToStep(body.marketing, s);
  if (product + marketing > s.roundBudget) marketing = s.roundBudget - product;
  return { tier, product, marketing, bold: cleanText(body.bold, MOVE_MAX) };
}

// ---------- Bots ----------

const botTimers = new Set();

function botChoice(s, t) {
  const r = Math.random;
  const tier = TIERS[Math.floor(r() * 3)];
  const steps = s.roundBudget / s.budgetStep;
  const p = Math.floor(r() * (steps + 1));
  const m = Math.floor(r() * (steps - p + 1));
  return {
    tier,
    product: p * s.budgetStep,
    marketing: m * s.budgetStep,
    bold: s.botMoves.length ? s.botMoves[Math.floor(r() * s.botMoves.length)] : '',
  };
}

function scheduleBots() {
  const s = scenario();
  const secs = roundSeconds();
  for (const t of activeTeams().filter((x) => x.bot)) {
    const delay = 1500 + Math.random() * Math.min(secs * 1000 * 0.5, 15000);
    const timer = setTimeout(() => {
      botTimers.delete(timer);
      if (state.phase !== 'round' || !state.teams[t.id] || t.out) return;
      t.submission = { ...botChoice(s, t), at: Date.now() };
      changed();
    }, delay);
    botTimers.add(timer);
  }
}

function clearBotTimers() {
  for (const t of botTimers) clearTimeout(t);
  botTimers.clear();
}

function addBots(n = 10) {
  const s = scenario();
  const taken = new Set(Object.values(state.teams).map((t) => t.name.toLowerCase()));
  const names = s.botNames.filter((x) => !taken.has(x.toLowerCase()));
  let added = 0;
  for (let i = 0; i < n && state.order.length < MAX_TEAMS; i++) {
    const name = names[i] || `Bot Team ${state.order.length + 1}`;
    const t = newTeam(`${name}`, true);
    if (state.phase === 'round') {
      t.submission = { ...botChoice(s, t), at: Date.now() };
    }
    added++;
  }
  return added;
}

// ---------- Rounds ----------

function startRound() {
  const s = scenario();
  if (state.round >= s.rounds) return 'The game has finished its last round.';
  if (!activeTeams().length) return 'No teams have joined yet.';
  state.round++;
  state.phase = 'round';
  state.showRules = false;
  state.deadline = Date.now() + roundSeconds() * 1000;
  for (const t of Object.values(state.teams)) t.submission = null;
  clearBotTimers();
  scheduleBots();
  return null;
}

function closeRound() {
  if (state.phase !== 'round') return;
  state.phase = 'closed';
  state.deadline = Date.now();
  clearBotTimers();
  // Bots that had not moved yet move now, so every bot plays every round.
  const s = scenario();
  for (const t of activeTeams()) if (t.bot && !t.submission) t.submission = { ...botChoice(s, t), at: Date.now() };
}

// The deadline is checked here so a round closes on time with nobody watching.
setInterval(() => {
  if (state.phase === 'round' && state.deadline && Date.now() >= state.deadline) {
    closeRound();
    changed();
  }
}, 500);

async function resolveRound() {
  if (state.phase === 'round') closeRound();
  if (state.phase !== 'closed') return 'There is no closed round to resolve.';
  const s = scenario();
  state.phase = 'resolving';
  changed();

  const round = state.round;
  const teams = activeTeams();
  // A team that sent nothing keeps its last price and spends nothing.
  const plays = teams.map((t) => {
    const last = t.history[t.history.length - 1];
    const sub = t.submission || { tier: last ? last.tier : 'mid', product: 0, marketing: 0, bold: '', auto: true };
    return { team: t, sub };
  });

  const judged = await ai.judgeRound(
    s,
    round,
    plays.map(({ team, sub }) => ({ id: team.id, name: team.name, tier: sub.tier, product: sub.product, marketing: sub.marketing, bold: sub.bold })),
    state.rounds.map((r) => r.shock && r.shock.headline).filter(Boolean)
  );
  addUsage(judged.usage, judged.calls);
  console.log(
    `[round ${round}] judged by ${judged.source} in ${judged.ms} ms, ${judged.calls} call(s), ` +
      `${judged.usage.inputTokens} tokens in, ${judged.usage.outputTokens} out, $${judged.usage.costUsd.toFixed(4)}` +
      `${judged.usage.estimated ? ' (estimated)' : ''}${judged.error ? ` (${judged.error})` : ''}`
  );

  // Someone may have pressed Reset while Claude was thinking.
  if (state.phase !== 'resolving' || state.round !== round) return null;

  const modifiers = {};
  for (const t of teams) modifiers[t.id] = judged.judged[t.id] ? judged.judged[t.id].modifier : 0;
  const results = resolveMarket(
    s,
    plays.map(({ team, sub }) => ({
      id: team.id,
      cash: team.cash,
      cumProduct: team.cumProduct,
      brand: team.brand,
      tier: sub.tier,
      product: sub.product,
      marketing: sub.marketing,
    })),
    judged.shock,
    modifiers
  );

  for (const { team, sub } of plays) {
    const r = results[team.id];
    const j = judged.judged[team.id] || {};
    team.cash = Math.max(0, r.cashEnd);
    team.cumProduct = r.cumProduct;
    team.brand = r.brand;
    team.totalCustomers += r.customers;
    team.totalRevenue += r.revenue;
    if (r.cashEnd <= 0) team.out = true;
    team.history.push({
      round,
      ...r,
      bold: sub.bold,
      auto: Boolean(sub.auto),
      verdict: sub.auto ? text(s).autoMove : j.verdict,
      quote: j.quote,
      outThisRound: r.cashEnd <= 0,
    });
  }

  rankTeams();
  state.rounds.push({ round, shock: judged.shock, source: judged.source, ms: judged.ms, error: judged.error || null, usage: judged.usage, calls: judged.calls, at: Date.now() });
  state.phase = 'results';
  changed();

  // After the last round, start writing the debrief so it is ready when the
  // host presses the button.
  if (round >= s.rounds) startDebrief();
  return null;
}

function rankTeams() {
  const s = scenario();
  const all = state.order.map((i) => state.teams[i]).filter(Boolean);
  const scores = scoreTeams(s, all);
  for (const t of all) {
    t.prevRank = t.rank;
    t.score = scores[t.id];
  }
  const sorted = [...all].sort((a, b) => b.score - a.score || b.totalCustomers - a.totalCustomers);
  sorted.forEach((t, i) => (t.rank = i + 1));
}

function standings() {
  return state.order
    .map((i) => state.teams[i])
    .filter(Boolean)
    .sort((a, b) => (a.rank || 999) - (b.rank || 999))
    .map((t) => {
      const tiers = {};
      for (const h of t.history) tiers[h.tier] = (tiers[h.tier] || 0) + 1;
      const mainTier = Object.entries(tiers).sort((a, b) => b[1] - a[1])[0];
      return { ...t, mainTier: mainTier ? mainTier[0] : 'mid' };
    });
}

// Running total of what Claude cost this game, for the admin page.
function addUsage(u, calls) {
  if (!u) return;
  const a = state.aiUsage || (state.aiUsage = { calls: 0, inputTokens: 0, outputTokens: 0, costUsd: 0, estimated: false });
  a.calls += calls || 0;
  a.inputTokens += u.inputTokens || 0;
  a.outputTokens += u.outputTokens || 0;
  a.costUsd += u.costUsd || 0;
  a.estimated = a.estimated || Boolean(u.estimated);
}

let debriefRun = 0;
function startDebrief() {
  if (state.debriefStatus === 'working') return;
  const run = ++debriefRun;
  state.debriefStatus = 'working';
  changed();
  ai.writeDebrief(scenario(), standings()).then((d) => {
    if (run !== debriefRun) return;
    addUsage(d.usage, d.source === 'ai' || d.error ? 1 : 0);
    console.log(`[debrief] written by ${d.source} in ${d.ms} ms, $${(d.usage.costUsd || 0).toFixed(4)}${d.error ? ` (${d.error})` : ''}`);
    state.debrief = d;
    state.debriefStatus = 'ready';
    changed();
  });
}

// ---------- Views ----------

function teamRow(t) {
  const last = t.history[t.history.length - 1];
  return {
    id: t.id,
    name: t.name,
    bot: t.bot,
    rank: t.rank,
    prevRank: t.prevRank,
    score: t.score,
    cash: t.cash,
    totalCustomers: t.totalCustomers,
    totalRevenue: t.totalRevenue,
    out: t.out,
    lastCustomers: last && last.round === state.round ? last.customers : null,
    lastTier: last ? last.tier : null,
  };
}

let publicCache = null;
function publicView() {
  const s = scenario();
  if (publicCache && publicCache.version === state.version && publicCache.scenario === s) return publicCache.view;
  const teams = state.order.map((i) => state.teams[i]).filter(Boolean);
  const lastRound = state.rounds[state.rounds.length - 1] || null;
  const showResults = state.rounds.length > 0;
  const highlights =
    lastRound && ['results', 'final'].includes(state.phase)
      ? teams
          .map((t) => ({ t, h: t.history.find((h) => h.round === lastRound.round) }))
          .filter((x) => x.h)
          .map(({ t, h }) => ({
            name: t.name,
            tier: h.tier,
            bold: h.bold,
            modifier: h.modifier,
            verdict: h.verdict,
            quote: h.quote,
            customers: h.customers,
          }))
      : [];
  const view = {
    version: `${state.version}-${s.id}-${(scenarioCache[s.id] || {}).mtime || 0}`,
    phase: state.phase,
    round: state.round,
    totalRounds: s.rounds,
    roundSeconds: roundSeconds(),
    deadline: state.deadline,
    joinUrl: `${BASE_URL}/play`,
    showRules: Boolean(state.showRules),
    scenario: {
      id: s.id,
      language: s.language,
      name: s.name,
      tagline: s.tagline,
      market: s.market,
      exampleMove: s.exampleMove || s.botMoves.find((x) => x) || '',
      unit: s.unit,
      units: s.units,
      startingCash: s.startingCash,
      roundBudget: s.roundBudget,
      budgetStep: s.budgetStep,
      fixedCostPerRound: s.fixedCostPerRound,
      tiers: s.tiers,
      score: s.score,
    },
    teams: teams.map((t) => ({ id: t.id, name: t.name, bot: t.bot, out: t.out, submitted: Boolean(t.submission), members: t.members })),
    submittedCount: teams.filter((t) => !t.out && t.submission).length,
    activeCount: teams.filter((t) => !t.out).length,
    leaderboard: showResults ? standings().map(teamRow) : [],
    lastRound: lastRound ? { round: lastRound.round, shock: lastRound.shock, source: lastRound.source } : null,
    highlights,
    debriefStatus: state.debriefStatus,
    debrief: state.phase === 'final' ? state.debrief : null,
  };
  publicCache = { version: state.version, scenario: s, view };
  return view;
}

function teamView(teamId) {
  const t = state.teams[teamId];
  if (!t) return null;
  return {
    id: t.id,
    name: t.name,
    members: t.members,
    cash: t.cash,
    rank: t.rank,
    score: t.score,
    out: t.out,
    totalCustomers: t.totalCustomers,
    totalRevenue: t.totalRevenue,
    submission: t.submission,
    history: t.history,
  };
}

// ---------- Rate limits ----------
// Light, in-memory, keyed by a device id the page sends plus the IP. A whole
// room behind one campus IP address still works because each phone has its
// own device id.

const buckets = new Map();
function limiter(name, max, windowMs) {
  return (req, res, next) => {
    const key = `${name}:${req.get('x-vw-device') || ''}:${req.ip}`;
    const now = Date.now();
    let b = buckets.get(key);
    if (!b || now > b.reset) {
      b = { n: 0, reset: now + windowMs };
      buckets.set(key, b);
    }
    b.n++;
    if (b.n > max) return res.status(429).json({ error: text(scenario()).errTooMany });
    next();
  };
}
setInterval(() => {
  const now = Date.now();
  for (const [k, b] of buckets) if (now > b.reset) buckets.delete(k);
}, 60000);

// ---------- App ----------

const app = express();
app.set('trust proxy', true);
app.use(express.json({ limit: '8kb' }));
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));

app.get('/', (req, res) => res.redirect('/play'));
app.get('/rules', (req, res) => res.redirect('/display?screen=rules'));

app.get('/api/state', (req, res) => {
  res.set('Cache-Control', 'no-store');
  const view = publicView();
  const team = req.query.team ? teamView(String(req.query.team)) : null;
  res.json({ ...view, now: Date.now(), me: team });
});

let qrCache = { url: null, svg: null };
app.get('/api/qr.svg', async (req, res) => {
  const url = `${BASE_URL}/play`;
  try {
    if (qrCache.url !== url) {
      qrCache = { url, svg: await QRCode.toString(url, { type: 'svg', margin: 1, color: { dark: '#00281b', light: '#ffffff' } }) };
    }
    res.type('image/svg+xml').set('Cache-Control', 'no-store').send(qrCache.svg);
  } catch (e) {
    res.status(500).send('The QR code could not be made.');
  }
});

app.post('/api/join', limiter('join', 12, 60000), (req, res) => {
  const T = text(scenario());
  if (state.phase === 'lobby') return res.status(409).json({ error: T.errNotOpen });
  if (state.phase === 'final') return res.status(409).json({ error: T.errEnded });
  const teamId = req.body.teamId ? String(req.body.teamId) : null;
  if (teamId) {
    const t = state.teams[teamId];
    if (!t || t.bot) return res.status(404).json({ error: T.errTeamGone });
    t.members++;
    changed();
    return res.json({ teamId: t.id, name: t.name });
  }
  const name = cleanText(req.body.name, NAME_MAX);
  if (name.length < 2) return res.status(400).json({ error: T.errNameShort });
  if (state.order.length >= MAX_TEAMS) return res.status(409).json({ error: T.errFull });
  const clash = Object.values(state.teams).find((t) => t.name.toLowerCase() === name.toLowerCase());
  if (clash) return res.status(409).json({ error: T.errNameTaken });
  const t = newTeam(name);
  changed();
  res.json({ teamId: t.id, name: t.name });
});

app.post('/api/submit', limiter('submit', 30, 60000), (req, res) => {
  const T = text(scenario());
  const t = state.teams[String(req.body.teamId || '')];
  if (!t) return res.status(404).json({ error: T.errYouGone });
  if (t.out) return res.status(409).json({ error: T.errOut });
  if (state.phase !== 'round') return res.status(409).json({ error: T.errClosed });
  const choice = validChoice(req.body);
  if (choice.error) return res.status(400).json({ error: choice.error });
  t.submission = { ...choice, at: Date.now() };
  changed();
  res.json({ ok: true, submission: t.submission });
});

// ---------- Admin ----------

const admin = express.Router();
admin.use(limiter('admin', 240, 60000));
admin.use((req, res, next) => {
  if (req.get('x-admin-pin') !== ADMIN_PIN) return res.status(401).json({ error: 'That PIN is wrong.' });
  next();
});

admin.get('/state', (req, res) => {
  res.json({
    ...publicView(),
    now: Date.now(),
    scenarios: listScenarios(),
    scenarioError,
    baseUrl: BASE_URL,
    fakeAI: ai.fakeAI(),
    model: ai.MODEL,
    rounds: state.rounds,
    roundSecondsSetting: state.roundSeconds,
    aiUsage: state.aiUsage,
    effort: ai.EFFORT,
    teamsDetail: state.order.map((i) => state.teams[i]).filter(Boolean).map((t) => ({ ...teamRow(t), members: t.members, submission: t.submission })),
  });
});

const act = (fn) => async (req, res) => {
  try {
    const err = await fn(req);
    if (err) return res.status(409).json({ error: err });
    changed();
    res.json({ ok: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message });
  }
};

admin.post(
  '/open-joining',
  act(() => {
    if (state.phase !== 'lobby') return 'Joining is already open.';
    state.phase = 'joining';
  })
);
admin.post('/start-round', act(() => (['joining', 'results'].includes(state.phase) ? startRound() : 'A round can start only from the lobby or from round results.')));
admin.post(
  '/end-round',
  act(() => {
    if (state.phase !== 'round') return 'No round is open.';
    closeRound();
  })
);
admin.post('/resolve', async (req, res) => {
  // Respond at once so the admin page does not hang while Claude thinks.
  if (!['round', 'closed'].includes(state.phase)) return res.status(409).json({ error: 'There is no round to resolve.' });
  resolveRound().catch((e) => {
    console.error('[resolve] failed:', e);
    if (state.phase === 'resolving') state.phase = 'closed';
    changed();
  });
  res.json({ ok: true });
});
admin.post(
  '/show-debrief',
  act(() => {
    if (state.phase !== 'results' || state.round < scenario().rounds) return 'The debrief opens after the last round is resolved.';
    if (state.debriefStatus === 'idle') startDebrief();
    state.phase = 'final';
  })
);
admin.post(
  '/load-bots',
  act(() => {
    if (state.phase === 'lobby') state.phase = 'joining';
    if (!addBots(10)) return 'The game is full.';
  })
);
admin.post(
  '/reset',
  act((req) => {
    clearBotTimers();
    debriefRun++;
    const keep = req.body && req.body.scenarioId ? String(req.body.scenarioId) : state.scenarioId;
    state = freshState(keep);
    state.version = Date.now();
  })
);
admin.post(
  '/scenario',
  act((req) => {
    if (!['lobby', 'joining'].includes(state.phase) || state.round > 0) return 'Change the market before round 1, or press Reset first.';
    const sid = path.basename(String(req.body.scenarioId || ''));
    try {
      loadScenario(sid);
    } catch (e) {
      return `That scenario could not be loaded. ${e.message}`;
    }
    state.scenarioId = sid;
    lastGoodScenario = null;
  })
);
admin.post(
  '/rules',
  act((req) => {
    state.showRules = Boolean(req.body && req.body.show);
  })
);
admin.post(
  '/round-seconds',
  act((req) => {
    const n = Number(req.body.seconds);
    state.roundSeconds = n >= 15 && n <= 300 ? Math.round(n) : null;
  })
);
admin.post(
  '/remove-team',
  act((req) => {
    const t = state.teams[String(req.body.teamId || '')];
    if (!t) return 'That team is not in the game.';
    delete state.teams[t.id];
    state.order = state.order.filter((x) => x !== t.id);
    if (state.round > 0) rankTeams();
  })
);
admin.post(
  '/rename-team',
  act((req) => {
    const t = state.teams[String(req.body.teamId || '')];
    const name = cleanText(req.body.name, NAME_MAX);
    if (!t) return 'That team is not in the game.';
    if (name.length < 2) return 'Type a name with at least two letters.';
    t.name = name;
  })
);

app.use('/api/admin', express.json(), admin);

app.get('/healthz', (req, res) => res.json({ ok: true, phase: state.phase, teams: state.order.length }));

restore();
// A market named at start wins over a saved game that has not started yet.
if ((ARG_SCENARIO || process.env.VW_SCENARIO) && state.round === 0) state.scenarioId = DEFAULT_SCENARIO;
scenario();
if (require.main === module) {
  app.listen(PORT, HOST, () => {
    console.log(`Launch Day is running on http://${HOST}:${PORT}`);
    console.log(`Players join at ${BASE_URL}/play`);
    console.log(`Projector: ${BASE_URL}/display    Admin: ${BASE_URL}/admin (PIN ${ADMIN_PIN})`);
    console.log(`AI: ${ai.fakeAI() ? 'test mode (VW_FAKE_AI=1)' : `claude -p --model ${ai.MODEL}`}`);
  });
}

module.exports = { app };
