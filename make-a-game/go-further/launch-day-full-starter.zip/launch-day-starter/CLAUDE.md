# Launch It! starter

Launch It! is a live classroom game. Teams run rival startups in one shared market. Each round they set a price, split a budget, and write one bold move, and Claude plays the market and the news. An instructor at the AIEE Build 1 workshop uses Claude Code to rewrite the game around a case they teach.

## How the game is built

- `server.js` runs the game. `npm run local` starts it for a room on the same wifi.
- `scenarios/` holds one JSON file per market. `campus-food.json` is the default and the model to copy. A scenario has the market description, customer segments, price tiers, news shocks, stock quotes, and bot teams.
- `npm run try-scenario -- <name>` plays a quick simulated game with no AI and prints how 24 fixed strategies finish.
- `public/` holds the three pages: `/play` for teams, `/display` for the projector, and `/admin` for the host. The host PIN is `launch`.
- The packages the game needs are already in `node_modules`. Do not run `npm install`.

## Rules for the workshop mission

- The mission is a new scenario file for the instructor's case. Copy `scenarios/campus-food.json`, keep every field, and keep the numbers on the same scale. Do not change any other file unless the instructor asks.
- Write the market text, segments, price notes, news shocks, stock quotes, and bot names and moves for their case, in plain English a student reads in a few seconds.
- Make the lowest price lose a little money on each sale, so the game teaches unit economics.
- Run `npm run try-scenario -- <name>` at most twice per request. Aim for a market where no single price wins everything and a careless team can run out of cash. Stop after the second run and report what you see, even if it is not perfect.
- Start the game with `npm run local -- --scenario=<name>`. If `claude --version` fails on this computer, start it with `npm run local:no-ai -- --scenario=<name>` instead, and tell the instructor that the market will use the scenario's own news and quotes.
- When the game starts, give the instructor the three addresses (play, display, admin) and the PIN.

## How to work with the instructor

- When the instructor asks for a plan, ask your questions one at a time, then propose a plan in five steps or fewer. Do not write anything until they say go.
- After a change, say in one or two plain sentences what changed and what to open or refresh.
- The instructor is a professor, often new to coding. Use plain words and skip code explanations unless they ask.
- They are on a $20 Claude plan, so read only the files you need. The `README.md` and `campus-food.json` are enough for the mission.
