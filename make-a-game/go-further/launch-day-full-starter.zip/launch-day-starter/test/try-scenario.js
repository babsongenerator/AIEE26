// Check a scenario file and play a quick simulated game with it, with no AI.
//
//   npm run try-scenario                      (the default campus food market)
//   npm run try-scenario -- ai-tutoring       (any file in scenarios/)
//
// It prints how 24 fixed strategies would finish after the scenario's rounds,
// so you can see whether the market is balanced before class: no single price
// should win everything, and a careless team should be able to run out of cash.

const fs = require('node:fs');
const path = require('node:path');
const { resolveMarket, scoreTeams, TIERS } = require('../lib/model');

const id = process.argv[2] || 'campus-food';
const file = path.join(__dirname, '..', 'scenarios', `${id}.json`);
let sc;
try {
  sc = JSON.parse(fs.readFileSync(file, 'utf8'));
} catch (e) {
  console.log(`The file scenarios/${id}.json could not be read as JSON.`);
  console.log(e.message);
  process.exit(1);
}

const need = ['name', 'market', 'startingCash', 'roundBudget', 'fixedCostPerRound', 'tiers', 'segments', 'model', 'score'];
const missing = need.filter((k) => sc[k] === undefined);
for (const t of TIERS) if (!sc.tiers || !sc.tiers[t]) missing.push(`tiers.${t}`);
if (missing.length) {
  console.log(`The scenario is missing these fields: ${missing.join(', ')}.`);
  process.exit(1);
}
const shares = sc.segments.reduce((a, s) => a + s.share, 0);
if (Math.abs(shares - 1) > 0.01) console.log(`Warning: the segment shares add up to ${shares.toFixed(2)}. They should add up to 1.`);

const step = sc.budgetStep || 5000;
const B = sc.roundBudget;
const splits = [
  [0, 0],
  [step, step],
  [Math.round(B / 3 / step) * step, Math.round(B / 3 / step) * step],
  [Math.round(B / 2 / step) * step, Math.round(B / 2 / step) * step],
  [B, 0],
  [0, B],
  [Math.round((B * 2) / 3 / step) * step, Math.round(B / 3 / step) * step],
  [Math.round(B / 3 / step) * step, Math.round((B * 2) / 3 / step) * step],
];
const teams = [];
for (const tier of TIERS) for (const [pr, mk] of splits) teams.push({ id: `${tier}-${pr}-${mk}`, tier, pr, mk, cash: sc.startingCash, cumProduct: 0, brand: 0, tc: 0, tr: 0 });

const rounds = sc.rounds || 3;
for (let r = 0; r < rounds; r++) {
  const plays = teams.filter((t) => t.cash > 0).map((t) => ({ id: t.id, cash: t.cash, cumProduct: t.cumProduct, brand: t.brand, tier: t.tier, product: t.pr, marketing: t.mk }));
  const res = resolveMarket(sc, plays, null, {});
  for (const t of teams) {
    const x = res[t.id];
    if (!x) continue;
    t.cash = Math.max(0, x.cashEnd);
    t.cumProduct = x.cumProduct;
    t.brand = x.brand;
    t.tc += x.customers;
    t.tr += x.revenue;
  }
}
const scores = scoreTeams(sc, teams.map((t) => ({ id: t.id, totalCustomers: t.tc, totalRevenue: t.tr, cash: t.cash })));
teams.sort((a, b) => scores[b.id] - scores[a.id]);

const money = (n) => `$${Math.round(n).toLocaleString('en-US')}`;
console.log(`${sc.name}: ${teams.length} simulated teams, ${rounds} rounds, no bold moves or news.\n`);
console.log('Price     Product  Marketing  ' + (sc.units || 'customers').padStart(10) + '     Revenue        Cash  Score');
for (const t of teams) {
  console.log(
    `${t.tier.padEnd(9)} ${money(t.pr).padStart(8)} ${money(t.mk).padStart(10)} ${t.tc.toLocaleString('en-US').padStart(11)} ${money(t.tr).padStart(11)} ${money(t.cash).padStart(11)} ${String(scores[t.id]).padStart(6)}`
  );
}
const topTiers = new Set(teams.slice(0, 6).map((t) => t.tier));
const broke = teams.filter((t) => t.cash <= 0).length;
console.log('');
console.log(topTiers.size === 1 ? `Warning: the top six all use the ${[...topTiers][0]} price. That price may be too strong.` : `The top six use ${topTiers.size} different prices.`);
console.log(broke ? `${broke} of ${teams.length} strategies run out of cash.` : 'No strategy runs out of cash. Consider a higher fixed cost or a lower starting cash.');
