# Make Launch It! your own

Launch It! is a startup market game for a classroom. In this starter, Claude Code rewrites the market around a case you teach. You change one file, the scenario. The game, the projector screen, and the AI market stay as they are.

You need Node and Claude Code Desktop, which the AIEE setup kit installed. You do not need an API key, and you do not need to run `npm install`.

## 1. Open the folder

1. Unzip the download. On a Mac, double-click the zip file. On Windows, right-click it and choose Extract All.
2. Open Claude Code Desktop and choose this folder as the project folder.

## 2. Plan your scenario

Copy the first prompt from aiee.jsims.dev/game, fill in your course and case, and paste it into Claude Code. Claude asks you a few questions about the case, then proposes a plan. Read the plan, ask for changes if you want any, and then type "go."

Claude writes a new scenario file, tests it twice with a quick simulated game, and starts the game. Say yes when Claude Code asks to run `npm run try-scenario` and `npm run local`.

## 3. Try it

1. Open the `/admin` address that Claude Code gives you. The PIN is `launch`.
2. Open the `/display` address in a second browser window. This is what the projector shows.
3. On the host page, press Add 10 bot teams.
4. Open the `/play` address on your phone or in a third window, and start a team of your own.
5. Press Start round 1, make your moves, and press Resolve round 1.
6. Read the news and the customer quotes. If something sounds wrong for your case, tell Claude Code what to change.

## The AI market

The AI market uses your own Claude Code login. A 3-round game with 12 teams uses about $0.13 of usage, which counts against your Claude plan. If Claude Code is logged out or missing, the game keeps going, and the market uses the news and quotes from your scenario file. To turn the AI off on purpose, start the game with `npm run local:no-ai -- --scenario=<your file name>`.

## Use it in class

1. Bring your laptop and connect it to the classroom wifi.
2. Run `npm run local -- --scenario=<your file name>`.
3. Put `/display` on the projector. Students scan the QR code or type the address on screen.
4. Run the game from `/admin` on your laptop.

Some campus networks keep devices from reaching each other. If students cannot open the page, connect your laptop and their phones to a phone hotspot.

Putting the game on the public internet needs hosting and an Anthropic API key. Ask Claude Code to walk you through both when you are ready.
